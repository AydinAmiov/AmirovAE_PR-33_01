package com.bignerdranch.android.amirov1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class ShapeSelectionActivity : AppCompatActivity() {

    private lateinit var spinner: Spinner;
    private lateinit var imgFormul: ImageView;
    private lateinit var firstField: EditText;
    private lateinit var secondField: EditText;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.shapeselectionactivity)

        spinner = findViewById(R.id.spinner);
        imgFormul = findViewById(R.id.img);
        firstField = findViewById(R.id.firstField);
        secondField = findViewById(R.id.secondField);

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?, view: View?, position: Int, id: Long
            ) {

                when (position) {
                    0 -> {
                        imgFormul.setImageResource(R.drawable.choicetriangle)
                        secondField.visibility = View.VISIBLE
                    }
                    1 -> {
                        imgFormul.setImageResource(R.drawable.choicekrug)
                        secondField.visibility = View.INVISIBLE
                    }
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }
    }

    fun makeCalculation(view: View) {
        when (spinner.selectedItemId.toInt()) {
            0 -> {
                if (firstField.text.isNotEmpty() && secondField.text.isNotEmpty()) {
                    val userNumber1 = Integer.parseInt(firstField.text.toString())
                    val userNumber2 = Integer.parseInt(secondField.text.toString())

                    if (userNumber1 in 1..9 && userNumber2 in 1..9) {
                        val result = ((2 * userNumber1 + userNumber2) * 10000.0).roundToInt() / 10000.0;

                        val intent = Intent(applicationContext, GeometricCalculatorActivity::class.java)
                        intent.putExtra("figure", "Треугольник");
                        intent.putExtra("result", result.toString());

                        startActivity(intent);
                    } else {
                        val toast = Toast.makeText(this, "Значения должны быть\nот 0 до 10", Toast.LENGTH_LONG)
                        toast.setGravity(Gravity.BOTTOM, 0, 160)
                        toast.show()
                    }
                } else {
                    val toast = Toast.makeText(this, "Введите значения для треугольника!", Toast.LENGTH_LONG)
                    toast.setGravity(Gravity.BOTTOM, 0, 160)
                    toast.show()
                }
            }
            1 -> {
                if (firstField.text.isNotEmpty()) {
                    val userNumber = Integer.parseInt(firstField.text.toString())

                    if (userNumber in 1..9) {
                        val result = ((userNumber / 2 * 3.14) * 10000.0).roundToInt() / 10000.0;

                        val intent = Intent(applicationContext, GeometricCalculatorActivity::class.java)
                        intent.putExtra("figure", "Круг");
                        intent.putExtra("result", result.toString());

                        startActivity(intent);
                    } else {
                        val toast = Toast.makeText(this, "Значение должно быть\nот 0 до 10", Toast.LENGTH_LONG)
                        toast.setGravity(Gravity.BOTTOM, 0, 160)
                        toast.show()
                    }
                } else {
                    val toast = Toast.makeText(this, "Введите начение для круга!", Toast.LENGTH_LONG)
                    toast.setGravity(Gravity.BOTTOM, 0, 160)
                    toast.show()
                }
            }
        }
    }
}