package com.bignerdranch.android.amirov1

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    var PREFS_FILE="Account";
    var PREF_LOGIN="Login";
    var PREF_PASSWORD="Password";
    var PREF_IS_ENTER="IS_ENTER"

    lateinit var settings: SharedPreferences;

    private lateinit var loginBox: EditText;
    private lateinit var passwordBox: EditText;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settings = getSharedPreferences(PREFS_FILE, MODE_PRIVATE)

        loginBox = findViewById(R.id.login_box)
        passwordBox = findViewById(R.id.password_box)
    }

    fun saveUserData(view: View) {
        val login:String = loginBox.text.toString();
        val password:String = passwordBox.text.toString();

        val prefEditor = settings.edit();

        prefEditor.putString(PREF_LOGIN, login);
        prefEditor.putString(PREF_PASSWORD, password);

        if(PREF_IS_ENTER == null) {
            prefEditor.putString(PREF_PASSWORD, "Был вход");
        }

        prefEditor.apply()
    }

    fun registration(view: View) {
        if (loginBox.text.toString().isNotEmpty() && passwordBox.text.toString().isNotEmpty()) {

            if(settings.getString(PREF_IS_ENTER, "не определено") == "Был вход") {
                if(loginBox.text.toString() == settings.getString(PREF_LOGIN, "не определено") &&
                    passwordBox.text.toString() == settings.getString(PREF_PASSWORD, "не определено")) {
                    val intent = Intent(applicationContext, ShapeSelectionActivity::class.java)
                    startActivity(intent)
                } else {
                    val toast = Toast.makeText(this, "Введите правильный логин и пароль!", Toast.LENGTH_LONG)
                    toast.setGravity(Gravity.BOTTOM, 0, 160)
                    toast.show()
                }
            } else {
                saveUserData(view);

                val login = settings.getString(PREF_LOGIN, "не определено");
                val password = settings.getString(PREF_PASSWORD, "не определено");

                val toast = Toast.makeText(
                    this, "Логин: $login.\n" +
                            "Пароль: $password", Toast.LENGTH_LONG
                )
                toast.setGravity(Gravity.BOTTOM, 0, 160)
                toast.show()

                loginBox.text = null;
                passwordBox.text = null;

                val intent = Intent(applicationContext, ShapeSelectionActivity::class.java)
                startActivity(intent)
            }

        } else {
            val toast = Toast.makeText(this, "Введите логин и пароль!", Toast.LENGTH_LONG)
            toast.setGravity(Gravity.BOTTOM, 0, 160)
            toast.show()
        }
}
}